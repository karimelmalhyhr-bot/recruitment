export default {
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310419663029755832/tWikVFKxUmOauSYh.svg",
};
